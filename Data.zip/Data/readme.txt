CMU AMP Face EXpression Database. 	April./2001  
 
________________________________________________________________

There are 13 subjects in this database, each with 75 images. We collected these face images in the same lighting condition, and only allow human expression changes. Each file is named as: "*##.bmp", where * is the index of subject, And ## is the index of face image for this subject.



Contact:

Prof.Tsuhan chen		tsuhan@cmu.edu
xiaoming Liu			xiaoming@andrew.cmu.edu